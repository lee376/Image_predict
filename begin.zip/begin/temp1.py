import torch
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from torch.utils.data import TensorDataset, DataLoader
import torchvision
from torchvision import transforms
from PIL import Image
from torch.utils.data import Dataset
from torch.utils.data import DataLoader
import os
imgs = []
# 打开第一步创建的txt文件，按行读取，将结果以元组方式保存在imgs里
# datainfo = open(r'C:\Users\43714\Desktop\DL-Task-for-6-main\test_seen_label.txt', 'r')
# for line in datainfo:
#     line = line.strip('\n')
#     words = line.split(' ')
#     imgs.append((words[0]+'.jpg', words[1]))
# print(imgs)
names = ['airplane','alarm_clock','ambulance','ant','apple','backpack','basket','butterfly','cactus','calculator','campfire','candle','coffee_cup','crab','duck','face','ice_cream','pig','pineapple','suitcase']
# dir = 'C:\Users\43714\Desktop\DL-Task-for-6-main\png\train\'
def walkFile(file,h):

    for root, dirs, files in os.walk(file + h):

        # root 表示当前正在访问的文件夹路径

        # dirs 表示该文件夹下的子目录名list

        # files 表示该文件夹下的文件list

        # 遍历文件

        for f in files:
            s = f
            # s = os.path.join(root, f).strip('C:\\Users\\43714\\Desktop\\DL-Task-for-6-main\\png\\train\\plane\\' + h) + 'png'
            print(s)

        # 遍历所有的文件夹

        # for d in dirs:
        #
        #     print(os.path.join(root, d))
        return s
a = []
for i in names:
    walkFile('C:\\Users\\43714\\Desktop\\DL-Task-for-6-main\\png\\train\\' , i)
    a.append(walkFile('C:\\Users\\43714\\Desktop\\DL-Task-for-6-main\\png\\train\\' , i))
print(len(a))